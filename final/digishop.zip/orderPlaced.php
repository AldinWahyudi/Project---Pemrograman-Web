
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <title>Pesanan Diterima</title>
  <link rel="stylesheet" href="css/orderPlaced.css" />
</head>
<body>
  <div class="message">
    <h1>✅ Pesanan Anda Berhasil!</h1>
    <p>Terima kasih telah berbelanja di toko kami.</p>
    <a href="index.php">Kembali ke Beranda</a>
  </div>
</body>
</html>
