<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title> FOOTER | E-COMMERCE WEBSITE BY EDYODA </title>
    <!-- EXTERNAL LINKS -->
    <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Lato&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/footer.css">
</head>

<body>
    <footer>
        <section>    
            <div id="containerFooter">
                
                <div id="webFooter">
                    <h3> online store </h3>
                    <p> Digital camera </p>
                    <p> Analog camera </p>
                    <p> Camera accessories </p>
                </div>
                <div id="webFooter">
                    <h3> helpful link </h3>
                    <p> home </p>
                    <p> about </p>
                    <p> contact </p>
                </div>
                <div id="webFooter">
                    <h3> partners </h3>
                    <p> canon </p>
                    <p> nikon </p>
                    <p> fujifilm </p>
                    <p> sony </p>
                    <p> + many more </p>
                </div>
                <div id="webFooter">
                    <h3> address </h3>
                    <p> building 101 </p>
                    <p> central avenue </p>
                    <p> la - 902722 </p>
                    <p> united states </p>
                </div>
            </div>
        </section>

    </footer>

</body>
</html>